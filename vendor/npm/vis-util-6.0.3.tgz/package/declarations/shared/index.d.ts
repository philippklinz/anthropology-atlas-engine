import type { default as HammerType } from "@egjs/hammerjs";
export declare const Activator: any;
export declare const ColorPicker: any;
export declare const Configurator: any;
export declare const Hammer: typeof HammerType;
export declare const Popup: any;
export declare const VALIDATOR_PRINT_STYLE: string;
export declare const Validator: any;
export * from "./configurator-types.ts";
//# sourceMappingURL=index.d.ts.map