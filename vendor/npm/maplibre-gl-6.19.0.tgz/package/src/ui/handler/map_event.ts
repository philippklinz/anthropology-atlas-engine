import {Evented} from '../../util/evented.ts';

import type {Handler, HandlerResult} from '../handler_manager.ts';
import type {MapEventType, MapMouseEvent, MapTouchEvent, MapWheelEvent} from '../events.ts';
import type {MapEventFactory} from '../map_event_factory.ts';
import type Point from '@mapbox/point-geometry';

export class MapEventHandler extends Evented<MapEventType> implements Handler {

    _mousedownPos: Point;
    _clickTolerance: number;
    _eventFactory: MapEventFactory;

    constructor(eventFactory: MapEventFactory, options: {
        clickTolerance: number;
    }) {
        super();
        this._eventFactory = eventFactory;
        this._clickTolerance = options.clickTolerance;
    }

    reset(): void {
        delete this._mousedownPos;
    }

    wheel(e: WheelEvent): HandlerResult | void {
        // If mapEvent.preventDefault() is called by the user, prevent handlers such as:
        // - ScrollZoom
        return this._firePreventable(this._eventFactory.createWheelEvent(e));
    }

    mousedown(e: MouseEvent, point: Point): HandlerResult | void {
        this._mousedownPos = point;
        // If mapEvent.preventDefault() is called by the user, prevent handlers such as:
        // - MousePan
        // - MouseRotate
        // - MousePitch
        // - DblclickHandler
        return this._firePreventable(this._eventFactory.createMouseEvent(e.type, e));
    }

    mouseup(e: MouseEvent): void {
        this.fire(this._eventFactory.createMouseEvent(e.type, e));
    }

    click(e: MouseEvent, point: Point): void {
        if (this._mousedownPos && this._mousedownPos.dist(point) >= this._clickTolerance) return;
        this.fire(this._eventFactory.createMouseEvent(e.type, e));
    }

    dblclick(e: MouseEvent): HandlerResult | void {
        // If mapEvent.preventDefault() is called by the user, prevent handlers such as:
        // - DblClickZoom
        return this._firePreventable(this._eventFactory.createMouseEvent(e.type, e));
    }

    mouseover(e: MouseEvent): void {
        this.fire(this._eventFactory.createMouseEvent(e.type, e));
    }

    mouseout(e: MouseEvent): void {
        this.fire(this._eventFactory.createMouseEvent(e.type, e));
    }

    touchstart(e: TouchEvent): HandlerResult | void {
        // If mapEvent.preventDefault() is called by the user, prevent handlers such as:
        // - TouchPan
        // - TouchZoom
        // - TouchRotate
        // - TouchPitch
        // - TapZoom
        // - SwipeZoom
        return this._firePreventable(this._eventFactory.createTouchEvent(e.type, e));
    }

    touchmove(e: TouchEvent): void {
        this.fire(this._eventFactory.createTouchEvent(e.type, e));
    }

    touchend(e: TouchEvent): void {
        this.fire(this._eventFactory.createTouchEvent(e.type, e));
    }

    touchcancel(e: TouchEvent): void {
        this.fire(this._eventFactory.createTouchEvent(e.type, e));
    }

    _firePreventable(mapEvent: MapMouseEvent | MapTouchEvent | MapWheelEvent): HandlerResult | void {
        this.fire(mapEvent);
        if (mapEvent.defaultPrevented) {
            // returning an object marks the handler as active and resets other handlers
            return {};
        }
    }

    isEnabled(): boolean {
        return true;
    }

    isActive(): boolean {
        return false;
    }
    enable(): void {}
    disable(): void {}
}

/**
 * A single finger held in place this long fires a long-press contextmenu.
 */
const LONG_PRESS_DELAY = 500;

export class BlockableMapEventHandler extends Evented<MapEventType> {
    _eventFactory: MapEventFactory;
    _clickTolerance: number;
    _delayContextMenu: boolean;
    _ignoreContextMenu: boolean;
    _contextMenuEvent: MouseEvent;
    _touchActive: boolean;
    _longPressTimer: ReturnType<typeof setTimeout>;
    _longPressStart: Point;

    constructor(eventFactory: MapEventFactory, options: {
        clickTolerance: number;
    }) {
        super();
        this._eventFactory = eventFactory;
        this._clickTolerance = options.clickTolerance;
    }

    reset(): void {
        this._delayContextMenu = false;
        this._ignoreContextMenu = true;
        delete this._contextMenuEvent;
        this._clearLongPress();
        this._touchActive = false;
    }

    mousemove(e: MouseEvent): void {
        // mousemove map events should not be fired when interaction handlers (pan, rotate, etc) are active
        this.fire(this._eventFactory.createMouseEvent(e.type, e));
    }

    mousedown(): void {
        this._delayContextMenu = true;
        this._ignoreContextMenu = false;
    }

    mouseup(): void {
        this._delayContextMenu = false;
        if (this._contextMenuEvent) {
            this.fire(this._eventFactory.createMouseEvent('contextmenu', this._contextMenuEvent));
            delete this._contextMenuEvent;
        }
    }

    /**
     * Starts the touch long press. Touch devices have no right click, so a long press opens
     * the context menu. It is detected with a timer rather than by relying on a native
     * contextmenu event, because Android Chrome fires one on a long press but iOS
     * Safari does not. A single finger held past the delay without moving fires a
     * contextmenu at that point; a pan or a lift cancels it.
     * @param e - the touch event
     * @param points - the touch points, in map coordinates
     * @param mapTouches - the touches that are on the map
     */
    touchstart(e: TouchEvent, points: Point[], mapTouches: Touch[]): void {
        this._clearLongPress();
        this._touchActive = mapTouches.length > 0;
        if (mapTouches.length !== 1) return; // single finger only, never during a pinch
        this._longPressStart = points[0];
        const touch = mapTouches[0];
        this._longPressTimer = setTimeout(() => {
            this._longPressTimer = undefined;
            const originalEvent = new MouseEvent('contextmenu', {clientX: touch.clientX, clientY: touch.clientY, button: 2, bubbles: true, cancelable: true});
            this.fire(this._eventFactory.createMouseEvent('contextmenu', originalEvent));
        }, LONG_PRESS_DELAY);
    }

    /**
     * Cancels a pending long press once the finger has moved further than the map's
     * click tolerance, or once a second finger lands.
     * @param e - the touch event
     * @param points - the touch points, in map coordinates
     * @param mapTouches - the touches that are on the map
     */
    touchmove(e: TouchEvent, points: Point[], mapTouches: Touch[]): void {
        if (!this._longPressTimer) return;
        if (mapTouches.length !== 1 || !this._longPressStart || points[0].dist(this._longPressStart) > this._clickTolerance) {
            this._clearLongPress();
        }
    }

    touchend(): void {
        this._touchActive = false;
        this._clearLongPress();
    }

    touchcancel(): void {
        this._touchActive = false;
        this._clearLongPress();
    }

    _clearLongPress(): void {
        if (this._longPressTimer) {
            clearTimeout(this._longPressTimer);
            this._longPressTimer = undefined;
        }
        this._longPressStart = undefined;
    }

    /**
     * Handles a contextmenu event. A native one during a touch is suppressed, because the
     * long press timer already fires the event and the browser menu would double up.
     * @param e - the mouse event
     */
    contextmenu(e: MouseEvent): void {
        if (this._touchActive) {
            e.preventDefault();
            return;
        }
        if (this._delayContextMenu) {
            // Mac: contextmenu fired on mousedown; we save it until mouseup for consistency's sake
            this._contextMenuEvent = e;
        } else if (!this._ignoreContextMenu) {
            // Windows: contextmenu fired on mouseup, so fire event now
            this.fire(this._eventFactory.createMouseEvent(e.type, e));
        }

        // prevent browser context menu when necessary
        if (this.listens('contextmenu')) {
            e.preventDefault();
        }
    }

    isEnabled(): boolean {
        return true;
    }

    isActive(): boolean {
        return false;
    }
    enable(): void {}
    disable(): void {}
}
