import {describe, expect, test} from 'vitest';
import {expectToBeCloseToArray} from '../../util/test/util.ts';
import {GlobeCoveringTilesDetailsProvider} from './globe_covering_tiles_details_provider.ts';
import {ConvexVolume} from '../../util/primitives/convex_volume.ts';
import {coveringTiles} from './covering_tiles.ts';
import {LngLat, earthRadius} from '../lng_lat.ts';
import {createCameraViewState} from '../../camera/camera_view_state.ts';
import {createCameraContext} from '../../camera/camera_context.ts';
import {projectCamera} from '../../camera/project_camera.ts';
import {resize, setBearing, setCenter, setPitch, setZoom} from '../../camera/camera_updates.ts';

import type {OverscaledTileID} from '../../tile/tile_id.ts';

function tileKey(tileID: OverscaledTileID): string {
    return `${tileID.canonical.z}/${tileID.canonical.x}/${tileID.canonical.y}`;
}

/** The distance of a volume's farthest point from the center of the unit sphere planet, on which 1 is the surface. */
function farthestPoint(volume: ConvexVolume): number {
    return Math.max(...volume.points.map((p) => Math.hypot(p[0], p[1], p[2])));
}

describe('bounding volume creation', () => {
    test('z=0', () => {
        const detailsProvider = new GlobeCoveringTilesDetailsProvider();
        const convex = detailsProvider.getTileBoundingVolume({
            x: 0,
            y: 0,
            z: 0,
        }, null, null, null);
        expect(convex).toEqual(ConvexVolume.fromAabb(
            [-1, -1, -1],
            [1, 1, 1],
        ));
    });

    test('z=1,x=0', () => {
        const detailsProvider = new GlobeCoveringTilesDetailsProvider();
        const convex = detailsProvider.getTileBoundingVolume({
            x: 0,
            y: 0,
            z: 1,
        }, null, null, null);
        expect(convex).toEqual(ConvexVolume.fromAabb(
            [-1, 0, -1],
            [0, 1, 1],
        ));
    });

    test('z=1,x=1', () => {
        const detailsProvider = new GlobeCoveringTilesDetailsProvider();
        const convex = detailsProvider.getTileBoundingVolume({
            x: 1,
            y: 0,
            z: 1,
        }, null, null, null);
        expect(convex).toEqual(ConvexVolume.fromAabb(
            [0, 0, -1],
            [1, 1, 1],
        ));
    });

    test('z=5,x=1,y=1', () => {
        const detailsProvider = new GlobeCoveringTilesDetailsProvider();
        const convex = detailsProvider.getTileBoundingVolume({
            x: 1,
            y: 1,
            z: 5,
        }, null, null, null);
        const precision = 10;
        const expectedMin = [-0.04878262717137475, 0.9918417649235776, -0.1250257487589308];
        const expectedMax = [-0.020462724105427713, 0.9944839919477184, -0.09690430455523656];
        const expectedPoints = [
            [-0.040144275638466294, 0.9946001124628003, -0.09691685469802916],
            [-0.04013795776704037, 0.9944589865528525, -0.09690160200714736],
            [-0.02046537424682884, 0.9946001124628002, -0.10288638417221826],
            [-0.020462153423906553, 0.9944589865528524, -0.10287019200194392],
            [-0.04902182691658952, 0.9919123845540323, -0.11834915939433684],
            [-0.049015509045163594, 0.9917712586440846, -0.11833390670345505],
            [-0.02499111064168652, 0.9919123845540323, -0.1256387974810376],
            [-0.02498788981876423, 0.9917712586440844, -0.12562260531076325]
        ];
        const expectedPlanes = [
            [0.033568258567807485, -0.9932912960221243, 0.11065971834147033, 1],
            [
                -0.033568258567807485,
                0.9932912960221243,
                -0.11065971834147033,
                -0.999857920923587
            ],
            [
                -0.2883372432854479,
                -0.11563909912606864,
                -0.9505205062952928,
                0.011318113428480242
            ],
            [
                0.2883372432854479,
                0.11563909912606864,
                0.9505205062952928,
                0.011924266779254289
            ],
            [
                0.9238795325112867,
                -3.8143839245115144e-17,
                -0.38268343236509017,
                0
            ],
            [-0.9807852804032307, 0, 0.19509032201612764, 0]
        ];
        expectToBeCloseToArray([...convex.min], expectedMin, precision);
        expectToBeCloseToArray([...convex.max], expectedMax, precision);
        expect(convex.points).toHaveLength(expectedPoints.length);
        for (let i = 0; i < convex.points.length; i++) {
            expectToBeCloseToArray([...convex.points[i]], expectedPoints[i], precision);
        }
        expect(convex.planes).toHaveLength(expectedPlanes.length);
        for (let i = 0; i < convex.planes.length; i++) {
            expectToBeCloseToArray([...convex.planes[i]], expectedPlanes[i], precision);
        }
    });
});

describe('elevated content above terrain', () => {
    test('terrain elevations do not shrink the content elevation allowance', () => {
        const detailsProvider = new GlobeCoveringTilesDetailsProvider();
        const terrain = {getMinMaxElevation: () => ({minElevation: 0, maxElevation: 100})};
        const contentElevation = 500000;
        const volume = detailsProvider.getTileBoundingVolume({x: 8, y: 5, z: 4}, 0, contentElevation, {tileSize: 512, terrain} as any);
        const shellRadius = 1 + contentElevation / earthRadius;
        const reach = Math.max(...volume.points.map((p) => Math.hypot(p[0], p[1], p[2])));
        expect(reach).toBeGreaterThanOrEqual(shellRadius * 0.999);
    });
});

describe('elevated content tile retention', () => {
    test('far corner translation keeps ground tiles retained at moderate pitch', () => {
        const context = createCameraContext({projection: 'globe'});
        let view = createCameraViewState({maxPitch: 179});
        view = resize(view, context, 1400, 800);
        view = setCenter(view, context, new LngLat(2.3522, 52.0566));
        view = setZoom(view, context, 4.3);
        view = setBearing(view, 315);
        view = setPitch(view, 75);
        const projectedCamera = projectCamera(view, context);
        const without = coveringTiles(projectedCamera, context.worldCoordinateHelper, {tileSize: 512}).map(tileKey);
        const withElevated = coveringTiles(projectedCamera, context.worldCoordinateHelper, {tileSize: 512, maxContentElevation: 500000}).map(tileKey);
        expect(without).toContain('4/9/4');
        expect(withElevated).toContain('4/9/4');
    });

    test('maxContentElevation keeps tiles that the horizon culling would drop', () => {
        const context = createCameraContext({projection: 'globe'});
        let view = createCameraViewState({maxPitch: 179});
        view = resize(view, context, 1400, 800);
        view = setCenter(view, context, new LngLat(2.35, 48.85));
        view = setZoom(view, context, 4.3);
        view = setPitch(view, 95);
        const projectedCamera = projectCamera(view, context);
        const without = coveringTiles(projectedCamera, context.worldCoordinateHelper, {tileSize: 512}).map(tileKey);
        const withElevated = new Set(coveringTiles(projectedCamera, context.worldCoordinateHelper, {tileSize: 512, maxContentElevation: 500000}).map(tileKey));
        for (const tile of without) {
            expect(withElevated, `visible ground tile ${tile} must stay retained`).toContain(tile);
        }
        expect(withElevated.size).toBeGreaterThan(without.length);
        expect(withElevated, 'a tile well beyond the surface horizon is retained').toContain('4/8/3');
    });
});

describe('poles', () => {
    test('covers the tiles around the south pole', () => {
        const context = createCameraContext({projection: 'globe'});
        let view = resize(createCameraViewState(), context, 512, 512);
        view = setCenter(view, context, new LngLat(0, -90));
        view = setZoom(view, context, 1.6);

        expect(coveringTiles(projectCamera(view, context), context.worldCoordinateHelper, {tileSize: 32})).toHaveLength(56);
    });
});

test('computes the bounding volume of a tile again once the terrain under it changes', () => {
    const detailsProvider = new GlobeCoveringTilesDetailsProvider();
    const dem: {minElevation?: number; maxElevation?: number} = {};
    const terrain = {getMinMaxElevation: () => ({...dem})};
    const options = {tileSize: 512, terrain} as any;
    const tile = {x: 8, y: 5, z: 4};

    const beforeDem = detailsProvider.getTileBoundingVolume(tile, 0, 0, options);
    dem.minElevation = 0;
    dem.maxElevation = 4000;
    const afterDem = detailsProvider.getTileBoundingVolume(tile, 0, 0, options);

    expect(afterDem).not.toBe(beforeDem);
    expect(farthestPoint(afterDem)).toBeGreaterThan(farthestPoint(beforeDem));
});
