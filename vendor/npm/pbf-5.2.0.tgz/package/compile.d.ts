export type ProtoSchema = {
    name?: string;
    syntax?: number;
    fields?: ProtoField[];
    values?: Record<string, {
        value: number;
    }>;
    enums?: ProtoSchema[];
    messages?: ProtoSchema[];
};
export type ProtoField = {
    name: string;
    type: string;
    tag: number | string;
    repeated?: boolean;
    oneof?: string | null;
    map?: {
        from: string;
        to: string;
    } | null;
    options: Record<string, any>;
};
export type CompileOptions = {
    /**
     * Generate a CommonJS module instead of ESM.
     */
    legacy?: boolean;
    /**
     * Don't generate read functions.
     */
    noRead?: boolean;
    /**
     * Don't generate write functions.
     */
    noWrite?: boolean;
    /**
     * Omit the version header comment.
     */
    dev?: boolean;
    /**
     * Generate TypeScript declarations for the module instead of the module itself.
     */
    dts?: boolean;
};
export type Context = {
    _proto: ProtoSchema;
    _children: Context[];
    _defaults: Record<string, any>;
    _mapEntries: Record<string, Context>;
    _name?: string;
    [name: string]: any;
};
/**
 * A message, enum or top-level schema in the format produced by `protocol-buffers-schema`.
 * @typedef {object} ProtoSchema
 * @property {string} [name]
 * @property {number} [syntax]
 * @property {ProtoField[]} [fields]
 * @property {Record<string, {value: number}>} [values]
 * @property {ProtoSchema[]} [enums]
 * @property {ProtoSchema[]} [messages]
 */
/**
 * @typedef {object} ProtoField
 * @property {string} name
 * @property {string} type
 * @property {number | string} tag
 * @property {boolean} [repeated]
 * @property {string | null} [oneof]
 * @property {{from: string, to: string} | null} [map]
 * @property {Record<string, any>} options
 */
/**
 * @typedef {object} CompileOptions
 * @property {boolean} [legacy] Generate a CommonJS module instead of ESM.
 * @property {boolean} [noRead] Don't generate read functions.
 * @property {boolean} [noWrite] Don't generate write functions.
 * @property {boolean} [dev] Omit the version header comment.
 * @property {boolean} [dts] Generate TypeScript declarations for the module instead of the module itself.
 */
/**
 * Compilation state for a message or enum; child types are also accessible by name, falling back to
 * ancestor scopes through the prototype chain so that type references resolve like in protobuf.
 * @typedef {{
 *     _proto: ProtoSchema,
 *     _children: Context[],
 *     _defaults: Record<string, any>,
 *     _mapEntries: Record<string, Context>,
 *     _name?: string,
 *     [name: string]: any
 * }} Context
 */
/**
 * Compiles a protobuf schema (as parsed by `pbf/resolve` or `protocol-buffers-schema`) into an
 * object with `read<Name>`/`write<Name>` functions for each message and a values object for each enum.
 * @param {ProtoSchema} proto
 * @returns {Record<string, any>}
 */
export declare function compile(proto: ProtoSchema): Record<string, any>;
/**
 * Compiles a protobuf schema into JavaScript module source code, or TypeScript declarations for it.
 * @param {ProtoSchema} proto
 * @param {CompileOptions} [options]
 * @returns {string}
 */
export declare function compileRaw(proto: ProtoSchema, options?: CompileOptions): string;
