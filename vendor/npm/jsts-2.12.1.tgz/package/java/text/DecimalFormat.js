export default function DecimalFormat() {}
