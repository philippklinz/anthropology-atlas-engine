export default function DecimalFormatSymbols() {}
