export default function Comparable() {}
