export default function Clonable() {}
