export default function LineNumberReader() {}
