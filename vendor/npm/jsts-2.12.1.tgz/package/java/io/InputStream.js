export default function InputStream() {}
