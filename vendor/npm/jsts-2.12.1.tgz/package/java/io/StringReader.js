export default function StringReader() {}
