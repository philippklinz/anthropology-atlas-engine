export default function PrintStream() {}
