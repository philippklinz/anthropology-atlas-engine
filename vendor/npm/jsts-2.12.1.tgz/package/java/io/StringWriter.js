export default function StringWriter() {}
