export default function OutputStream() {}
