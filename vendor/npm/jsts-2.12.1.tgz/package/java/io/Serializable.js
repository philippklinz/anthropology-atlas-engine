export default function Serializable() {}
