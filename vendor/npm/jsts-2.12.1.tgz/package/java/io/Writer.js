export default function Writer() {}
