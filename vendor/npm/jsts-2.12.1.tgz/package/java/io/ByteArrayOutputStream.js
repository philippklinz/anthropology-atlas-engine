export default function ByteArrayOutputStream() {}
