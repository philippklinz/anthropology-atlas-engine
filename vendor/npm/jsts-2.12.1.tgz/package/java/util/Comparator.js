export default function Comparator() {}
