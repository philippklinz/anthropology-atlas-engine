export default class AffineTransformationFactory {
    static createFromBaseLines(src0: any, src1: any, dest0: any, dest1: any): AffineTransformation;
    static createFromControlVectors(...args: any[]): any;
}
import AffineTransformation from './AffineTransformation.js';
