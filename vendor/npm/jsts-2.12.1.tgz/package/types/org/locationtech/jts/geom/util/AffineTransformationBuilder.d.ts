export default class AffineTransformationBuilder {
    static constructor_(...args: any[]): void;
    constructor(...args: any[]);
    compute(): boolean;
    _m00: any;
    _m01: any;
    _m02: any;
    _m10: any;
    _m11: any;
    _m12: any;
    getTransformation(): AffineTransformation;
    solve(b: any): any;
}
import AffineTransformation from './AffineTransformation.js';
