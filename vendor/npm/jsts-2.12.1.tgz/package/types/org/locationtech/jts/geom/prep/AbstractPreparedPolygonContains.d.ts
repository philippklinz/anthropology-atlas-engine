export default class AbstractPreparedPolygonContains extends PreparedPolygonPredicate {
    findAndClassifyIntersections(geom: any): void;
    _hasSegmentIntersection: boolean;
    _hasProperIntersection: boolean;
    _hasNonProperIntersection: boolean;
    eval(geom: any): any;
    isSingleShell(geom: any): boolean;
    isProperIntersectionImpliesNotContainedSituation(testGeom: any): boolean;
}
import PreparedPolygonPredicate from './PreparedPolygonPredicate.js';
