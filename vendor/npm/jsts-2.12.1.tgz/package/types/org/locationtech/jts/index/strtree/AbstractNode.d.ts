export default class AbstractNode {
    static constructor_(...args: any[]): void;
    constructor(...args: any[]);
    getLevel(): any;
    addChildBoundable(childBoundable: any): void;
    isEmpty(): any;
    getBounds(): any;
    _bounds: any;
    size(): any;
    getChildBoundables(): any;
    get interfaces_(): (typeof Serializable | typeof Boundable)[];
}
import Serializable from '../../../../../java/io/Serializable.js';
import Boundable from './Boundable.js';
