export default class Area {
    static ofRingSigned(...args: any[]): number;
    static ofRing(...args: any[]): number;
}
