export default class AreaSimilarityMeasure {
    measure(g1: any, g2: any): number;
    get interfaces_(): (typeof SimilarityMeasure)[];
}
import SimilarityMeasure from './SimilarityMeasure.js';
