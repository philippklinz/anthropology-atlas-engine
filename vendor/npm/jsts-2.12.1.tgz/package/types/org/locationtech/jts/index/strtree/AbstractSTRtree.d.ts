declare class AbstractSTRtree {
    static constructor_(...args: any[]): void;
    static compareDoubles(a: any, b: any): 1 | -1 | 0;
    constructor(...args: any[]);
    queryInternal(...args: any[]): void;
    insert(bounds: any, item: any): void;
    boundablesAtLevel(...args: any[]): ArrayList;
    getRoot(): any;
    remove(...args: any[]): any;
    createHigherLevels(boundablesOfALevel: any, level: any): any;
    depth(...args: any[]): any;
    createParentBoundables(childBoundables: any, newLevel: any): ArrayList;
    isEmpty(): any;
    getNodeCapacity(): any;
    lastNode(nodes: any): any;
    size(...args: any[]): any;
    removeItem(node: any, item: any): boolean;
    itemsTree(...args: any[]): any;
    query(...args: any[]): ArrayList;
    build(): any;
    _root: any;
    _itemBoundables: any;
    _built: boolean;
    get interfaces_(): (typeof Serializable)[];
}
declare namespace AbstractSTRtree {
    export let _root: any;
    export let _built: boolean;
    export let _itemBoundables: ArrayList;
    export let _nodeCapacity: any;
    export { IntersectsOp };
    export let DEFAULT_NODE_CAPACITY: number;
}
export default AbstractSTRtree;
import ArrayList from '../../../../../java/util/ArrayList.js';
import Serializable from '../../../../../java/io/Serializable.js';
declare function IntersectsOp(): void;
