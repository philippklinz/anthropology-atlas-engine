declare class Angle {
    static toDegrees(radians: any): number;
    static isAcute(p0: any, p1: any, p2: any): boolean;
    static isObtuse(p0: any, p1: any, p2: any): boolean;
    static interiorAngle(p0: any, p1: any, p2: any): number;
    static normalizePositive(angle: any): any;
    static angleBetween(tip1: any, tail: any, tip2: any): number;
    static diff(ang1: any, ang2: any): number;
    static toRadians(angleDegrees: any): number;
    static normalize(angle: any): any;
    static angle(...args: any[]): number;
    static getTurn(ang1: any, ang2: any): number;
    static angleBetweenOriented(tip1: any, tail: any, tip2: any): number;
}
declare namespace Angle {
    let PI_TIMES_2: number;
    let PI_OVER_2: number;
    let PI_OVER_4: number;
    let COUNTERCLOCKWISE: number;
    let CLOCKWISE: number;
    let NONE: number;
}
export default Angle;
