export default class EdgeSetIntersector {}
