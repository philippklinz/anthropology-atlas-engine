export default class Lineal {}
