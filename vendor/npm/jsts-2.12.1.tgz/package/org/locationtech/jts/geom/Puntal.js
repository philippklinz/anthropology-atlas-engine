export default class Puntal {}
