export default class Polygonal {}
